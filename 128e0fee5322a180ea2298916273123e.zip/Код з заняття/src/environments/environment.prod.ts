export const environment = {
  production: true,
  BACKEND_URL: 'http://localhost:3000'
};

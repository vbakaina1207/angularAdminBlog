import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offerta',
  templateUrl: './offerta.component.html',
  styleUrls: ['./offerta.component.scss']
})
export class OffertaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
